# README

# The Political Economy of Life Satisfaction

- Nisha Bellinger
- Jonathan Krieckhaus
- Byunghwan Son (contact: bson3@gmu.edu)

For replication, we offer Stata do-files. There are two: 1) 'data' 2) 'analysis'.
With the 'data' file one can create the data set we used for analysis from scratch. The 'analysis' file runs all the regression analyses we have in the manuscript and re-creates all the figures. With right set-up of folders, you should be able to do this with a single click. 

Because WVS does not allow posting the data (and the size of the data set is too large), we do *not* post the data here.

